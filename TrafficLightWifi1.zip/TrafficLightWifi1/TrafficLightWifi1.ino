// --- VisioLite Dynamic Debugger (Wi-Fi Mode) ---
// Этот файл просто запускает логику из TrafficLightWifi1.cpp

#include "TrafficLightWifi1.h"

TrafficLightWifi1 logic;

void setup() {
  // Вся настройка внутри класса
  logic.setup();
}

void loop() {
  // Запуск шага автомата
  logic.loop();
}
