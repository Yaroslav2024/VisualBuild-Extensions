#include "TrafficLightWifi1.h"

const char* WIFI_SSID = "LAPTOP-VJ3LH3KR3932";
const char* WIFI_PASS = "^4u973M7";

TrafficLightWifi1::TrafficLightWifi1() {
    server = new WiFiServer(8080);
    activeCount = 1;
    isRunning = true;
}

void TrafficLightWifi1::setup() {
    Serial.begin(115200);
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    
    // We are waiting endlessly to connect to the router
    while (WiFi.status() != WL_CONNECTED) delay(500);
    server->begin();
    
    // Wait for TCP client
    while (!client || !client.connected()) {
        client = server->available();
        delay(10);
    }
    FSM_Init();
}

void TrafficLightWifi1::dbg_sig(char type, int id) {
    if (client && client.connected()) {
        client.print("["); client.print(type); client.print(":");
        client.print(id); client.println("]");
    }
}

void TrafficLightWifi1::loop() {
    // Восстанавливаем связь, если IDE переподключилась на лету
    if (!client || !client.connected()) {
        WiFiClient newClient = server->available();
        if (newClient) client = newClient;
    }
    if (isRunning) FSM_Tick();
}

void TrafficLightWifi1::requestTransition(int i, StateFunc target) {
    activeFSMs[i].nextState = target;
    activeFSMs[i].flags |= FLAG_EXIT;
}

void TrafficLightWifi1::FSM_Init() {
    activeFSMs[0].current = &TrafficLightWifi1::state_1_func;
    activeFSMs[0].flags = FLAG_ENTER;
}

void TrafficLightWifi1::FSM_Tick() {
    for(int i = 0; i < activeCount; i++) {
        if (activeFSMs[i].current == nullptr) continue;

        if (activeFSMs[i].flags & FLAG_EXIT) {
            if (activeFSMs[i].current != activeFSMs[i].nextState) {
            (this->*(activeFSMs[i].current))(i);
            }
            activeFSMs[i].previousState = activeFSMs[i].current;
            activeFSMs[i].current = activeFSMs[i].nextState;
            if (activeFSMs[i].current != nullptr) activeFSMs[i].flags = FLAG_ENTER;
            else activeFSMs[i].flags = 0;
        } else {
            (this->*(activeFSMs[i].current))(i);
        }
    }
}

// ==========================================
// State ID: 1
void TrafficLightWifi1::state_1_func(int i) {
    if (activeFSMs[i].flags & FLAG_ENTER) {
        dbg_sig('B', 1);
        setupHardware();
        activeFSMs[i].stateStartTime = millis();
        activeFSMs[i].flags &= ~FLAG_ENTER;
        return;
    }

    if (activeFSMs[i].flags & FLAG_EXIT) {
        return;
    }

    if (getDistance() < 15) {
        dbg_sig('T', 1000);
        requestTransition(i, &TrafficLightWifi1::state_2_func);
        return;
    }
}

// ==========================================
// State ID: 2
void TrafficLightWifi1::state_2_func(int i) {
    if (activeFSMs[i].flags & FLAG_ENTER) {
        dbg_sig('B', 2);
        Serial.println("Object detected!");
        activeFSMs[i].stateStartTime = millis();
        activeFSMs[i].flags &= ~FLAG_ENTER;
        return;
    }

    if (activeFSMs[i].flags & FLAG_EXIT) {
        return;
    }

    if (getDistance() >= 15) {
        dbg_sig('T', 1001);
        requestTransition(i, &TrafficLightWifi1::state_1_func);
        return;
    }
}

