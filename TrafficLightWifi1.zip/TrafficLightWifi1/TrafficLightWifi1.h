#ifndef TRAFFICLIGHTWIFI1_H
#define TRAFFICLIGHTWIFI1_H

#include <stdint.h>
#if defined(ARDUINO)
    #include <Arduino.h>
    #include <WiFi.h>
#endif

// --- User Libraries ---
#include <Arduino.h>

// --- Flags ---
#define FLAG_ENTER (1u << 0)
#define FLAG_EXIT  (1u << 1)

class TrafficLightWifi1 {
public:
    // --- User Variables & Methods ---

// --- Пины Ультразвукового датчика ---
// По вашему сообщению: Trig (отправка) и Echo (чтение)
const int TRIG_PIN = 12; 
const int ECHO_PIN = 13; 

// Функция настройки пинов
void setupHardware() {
    pinMode(TRIG_PIN, OUTPUT);
    pinMode(ECHO_PIN, INPUT);
}

// Умная функция замера дистанции (без зависаний)
int getDistance() {
    digitalWrite(TRIG_PIN, LOW);
    delayMicroseconds(2);
    digitalWrite(TRIG_PIN, HIGH);
    delayMicroseconds(10);
    digitalWrite(TRIG_PIN, LOW);
    
    // Ждем эхо максимум 30 миллисекунд (чтобы автомат не вис)
    long duration = pulseIn(ECHO_PIN, HIGH, 30000); 
    
    if (duration == 0) {
        return 100; // Никого нет, возвращаем безопасные 100 см
    } 
    
    return duration * 0.034 / 2; // Возвращаем реальные сантиметры
}

    // --- Types of functions (Pointer to Class Member) ---
    typedef void (TrafficLightWifi1::*StateFunc)(int tokenIdx);

    // --- FSM structure ---
    typedef struct {
        StateFunc     current;
        StateFunc     nextState;
        StateFunc     previousState;
        uint8_t       flags;
        unsigned long stateStartTime;
    } FSM;

    TrafficLightWifi1();
    void setup();
    void loop();

private:
    FSM activeFSMs[1];
    int activeCount;
    bool isRunning;
    WiFiServer* server;
    WiFiClient client;

    // Core FSM API
    void FSM_Init();
    void FSM_Tick();
    void requestTransition(int i, StateFunc target);
    void dbg_sig(char type, int id);

    // Variables extracted from blocks

    // State Prototypes
    void state_1_func(int i);
    void state_2_func(int i);
};

#endif
